# Easy Thermal Rebalance

## Mod info

| Field | Value |
|---|---|
| Name | Easy Thermal Rebalance |
| Mod ID | `qiu.EasyThermalRebalance` |
| Version | 1.2.0 |
| Author | qiu |

## What it does

KSP2 part heat limits are only 40%-60% of their KSP1 equivalents, so parts overheat very easily.
This mod raises every part's `maxTemp` to **75% of its KSP1 reference value**, never below the
part's original KSP2 limit.

A few parts - engine mounts among them - do not use the proportional value: their limits are
**set manually to a fixed temperature** (see "Parts adjusted" below).

## Parts adjusted

**475 parts** in total; 461 of them get a higher limit (the other 14 were already higher and stay
unchanged).

| Category | Parts | Median before (K) | Median after (K) |
|---|---|---|---|
| Structural | 105 | 850 | 1500 |
| FuelTank | 87 | 1000 | 1725 |
| Engine | 45 | 1000 | 1500 |
| Utility (ladders / lights / chutes) | 45 | 850 | 1500 |
| Aero | 39 | 1250 | 1800 |
| Payload (cabins / bays / fairings) | 37 | 1000 | 1950 |
| Pods | 28 | 800 | 900 |
| Coupling | 27 | 1000 | 1500 |
| Electrical | 24 | 600 | 900 |
| Science | 10 | 600 | 900 |
| Communication | 9 | 600 | 1500 |
| Thermal (heat shields / radiators) | 9 | 1700 | 2475 |
| Ground | 9 | 750 | 900 |

Parts with a clear role use the actual KSP1 value x 0.75: heat shields **2475 K**, fairings and
cargo bays **1950 K**, radiators and parachutes **1875 K**, ladders / solar panels / antennas /
docking ports **1500 K**, science parts / batteries / crew cabins **900 K**.

Engine mounts are fixed at **2000 K** (exempt from the 75% scale): MEM-125, MEM-250, MEM-375,
MEM-500 and `engine_mount_1.5v`. The Mk3 EM-500 "Hotplate" (`enginemount_3v_m3`) is excluded and
stays at **1500 K**.

The full 475-row list (original and adjusted limit for every part) is in
`thermal_rebalance_review.csv`.
